public interface RevistaObserver{
	
	public void update(RevistaSubject revistaSubject);
}