public class DataGenerator {
	
	public FIFO generateData() {
		FIFO fifo = new FIFO();
		fifo.add("Jullia");
		fifo.add("Iago");
		fifo.add("Cleusa");
		fifo.add("Rafael");
		return fifo;
	}
}
