public class ArvoreNatalBasica implements ArvoreNatal{
	
	public String getDescricao() {
		return "Pinheiro Natural";
	}
}
