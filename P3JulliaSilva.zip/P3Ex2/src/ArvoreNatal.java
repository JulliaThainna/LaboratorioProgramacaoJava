public interface ArvoreNatal {
	
	public String getDescricao();
}
